@switch($categoria_id)
    @case(1)
        LISTAR LOS PRODUCTOS DE ELECTRONICA
        @break
    @case(2)
        LISTAR LOS ELECTRODOMESTICOS
        @break
    @case(3)
        LISTAR LA ROPA
        @break
        
@endswitch